from django.contrib import admin

# Register your models here.
from .models import Stocks
admin.site.register(Stocks)